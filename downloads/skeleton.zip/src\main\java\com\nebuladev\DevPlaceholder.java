package com.nebuladev;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Заглушка dev-мода.
 * Нужна только чтобы у Gradle-проекта был свой компилируемый entrypoint.
 * Сам чит Nebula грузится из jar в run/mods.
 */
public class DevPlaceholder implements ModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger("nebula-dev");

    @Override
    public void onInitialize() {
        LOGGER.info("[nebula-dev] Zaglushka zagruzhena. Chit Nebula gruzitsya iz run/mods/Nebula.jar");
    }
}
